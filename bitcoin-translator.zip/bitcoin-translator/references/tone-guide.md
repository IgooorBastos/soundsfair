# Bitcoin Starter - Tone & Voice Guide

Translation guide for maintaining consistent voice and tone across all Bitcoin Starter educational content.

## Brand Voice Principles

### Core Identity: "Fair Money for a Free World"

Bitcoin Starter is:
- **Educational** - Teaching, not preaching
- **Intellectual** - Facts over hype
- **Libertarian** - Individual sovereignty focus
- **Welcoming** - Accessible to beginners
- **Honest** - Acknowledges tradeoffs and challenges

Bitcoin Starter is NOT:
- ❌ Marketing material hyping Bitcoin
- ❌ Get-rich-quick schemes
- ❌ Technical documentation (too dry)
- ❌ Preachy manifestos
- ❌ Tribalistic or maximalist in tone

---

## Translation Voice Guidelines

### 1. Be Welcoming But Intellectually Honest

✅ **Do:**
- Welcome beginners warmly
- Explain concepts clearly
- Acknowledge when things are complex
- Encourage critical thinking

❌ **Don't:**
- Talk down to readers
- Oversimplify to point of inaccuracy
- Assume everyone agrees with your worldview
- Shame people for not knowing

**Example:**

| Portuguese Source | ❌ Bad Translation | ✅ Good Translation |
|-------------------|-------------------|---------------------|
| "Bitcoin é a solução para todos os problemas monetários" | "Bitcoin is the solution to all monetary problems" | "Bitcoin offers an alternative to the current monetary system, though it's not without tradeoffs" |

### 2. Facts Over Hype

✅ **Do:**
- Present data and evidence
- Cite sources
- Use specific numbers
- Show, don't just tell

❌ **Don't:**
- Use superlatives unnecessarily ("revolutionary", "amazing", "incredible")
- Make price predictions
- Guarantee outcomes
- Use marketing buzzwords

**Example:**

| Portuguese Source | ❌ Bad Translation | ✅ Good Translation |
|-------------------|-------------------|---------------------|
| "Bitcoin vai revolucionar completamente o sistema financeiro" | "Bitcoin will completely revolutionize the financial system" | "Bitcoin enables peer-to-peer value transfer without intermediaries, challenging traditional financial systems" |

### 3. Libertarian Philosophy Without Being Preachy

✅ **Do:**
- Emphasize individual sovereignty
- Explain economic concepts (Austrian economics)
- Discuss freedom and privacy
- Present philosophical arguments

❌ **Don't:**
- Attack people who disagree
- Use tribal language
- Assume readers share your politics
- Be aggressive or confrontational

**Example:**

| Portuguese Source | ❌ Bad Translation | ✅ Good Translation |
|-------------------|-------------------|---------------------|
| "Bancos centrais roubam seu dinheiro através da inflação" | "Central banks steal your money through inflation" | "Central banks expand the money supply, which reduces the purchasing power of existing currency - a process called inflation" |

### 4. Educational, Not Preachy

✅ **Do:**
- Explain *why*, not just *what*
- Use analogies and examples
- Break down complex topics
- Provide context

❌ **Don't:**
- Tell people what to do
- Use "you should" statements
- Assume moral superiority
- Preach or evangelize

**Example:**

| Portuguese Source | ❌ Bad Translation | ✅ Good Translation |
|-------------------|-------------------|---------------------|
| "Você precisa comprar Bitcoin agora para proteger seu futuro" | "You need to buy Bitcoin now to protect your future" | "Many people choose to hold some bitcoin as a hedge against inflation and currency devaluation" |

### 5. Accessible to Beginners

✅ **Do:**
- Define terms on first use
- Use simple language when possible
- Provide context
- Build concepts progressively

❌ **Don't:**
- Use unexplained jargon
- Assume prior knowledge
- Skip fundamental concepts
- Be condescending about complexity

**Example:**

| Portuguese Source | ❌ Bad Translation | ✅ Good Translation |
|-------------------|-------------------|---------------------|
| "O halving reduz a inflação" | "The halving reduces inflation" | "Every four years, Bitcoin's issuance rate gets cut in half - an event called the 'halving' - which reduces new supply entering circulation" |

---

## Writing Style Patterns

### Active vs Passive Voice

**Prefer active voice:**

| ❌ Passive (Avoid) | ✅ Active (Prefer) |
|--------------------|-------------------|
| "Transactions are verified by miners" | "Miners verify transactions" |
| "The network is secured through proof-of-work" | "Proof-of-work secures the network" |
| "Bitcoin was created by Satoshi" | "Satoshi created Bitcoin" |

**Exception:** Passive is OK when the actor is unknown or unimportant.

### Sentence Length

**Vary sentence length for readability:**

- Short sentences (5-10 words): Emphasize key points
- Medium sentences (10-20 words): Standard explanations
- Long sentences (20-30 words): Complex concepts needing detail

**Example:**
"Bitcoin is scarce. Only 21 million will ever exist. This fixed supply distinguishes it from fiat currencies, which central banks can print infinitely, devaluing existing money."

### Paragraph Structure

**Each paragraph should:**
1. Start with a clear topic sentence
2. Develop one main idea
3. Connect to previous/next paragraphs
4. Be 3-5 sentences (not walls of text)

---

## Tone Adjustments by Content Type

### For Beginner Content (Levels 1-3)

**Tone:** Friendly, patient, encouraging

✅ **Do:**
- Use simple analogies
- Define every technical term
- Celebrate small wins
- Acknowledge confusion is normal

**Example:**
"Think of a Bitcoin wallet like your email account. Just as you need a password to access your email, you need a private key to access your bitcoin. The difference? If you lose your Bitcoin private key, there's no 'forgot password' button. This makes security crucial."

### For Intermediate Content (Levels 4-6)

**Tone:** Instructive, detailed, practical

✅ **Do:**
- Dive deeper into mechanics
- Explain tradeoffs
- Provide practical guidance
- Connect concepts

**Example:**
"Running your own node gives you full verification of Bitcoin's supply and rules, but requires ~700GB of storage and technical knowledge. Many users start with light wallets, then progress to full nodes as they learn more."

### For Advanced Content (Levels 7-8)

**Tone:** Analytical, nuanced, philosophical

✅ **Do:**
- Explore implications
- Discuss edge cases
- Present multiple perspectives
- Engage with complexity

**Example:**
"Bitcoin's supply schedule creates interesting game theory dynamics. Early adopters benefit from lower prices but higher uncertainty. Later adopters face higher prices but more established infrastructure. Neither is objectively 'better' - it depends on individual time preference and risk tolerance."

---

## Common Translation Traps

### Trap 1: Literal Translation Sounds Awkward

**Portuguese often uses more words:**

| Portuguese (literal) | ❌ Direct Translation | ✅ Natural English |
|---------------------|----------------------|-------------------|
| "O processo de mineração de Bitcoin é realizado por computadores..." | "The process of Bitcoin mining is realized by computers..." | "Bitcoin mining happens when computers..." |

### Trap 2: Cultural References Don't Translate

**Brazilian context → International audience:**

| Portuguese Context | ❌ Direct Translation | ✅ Adapted Translation |
|-------------------|----------------------|----------------------|
| "Como vimos com o Plano Real em 1994..." | "As we saw with the Real Plan in 1994..." | "Similar to currency reforms throughout history, such as Brazil's Real Plan (1994) or Germany's post-hyperinflation reforms..." |

### Trap 3: False Friends (Words That Look Similar)

| Portuguese | ❌ Wrong English | ✅ Correct English |
|-----------|-----------------|-------------------|
| "eventualmente" | "eventually" | "possibly" or "potentially" |
| "atualmente" | "actually" | "currently" |
| "realizar" | "realize" (understand) | "accomplish" or "perform" |

### Trap 4: Adding Unnecessary Hype

**Don't add excitement not in the original:**

| Portuguese | ❌ Added Hype | ✅ Faithful Translation |
|-----------|--------------|----------------------|
| "Bitcoin permite transações sem intermediários" | "Bitcoin amazingly revolutionizes transactions by removing intermediaries!" | "Bitcoin enables transactions without intermediaries" |

---

## Tone Checklist

Before finalizing a translation, ask:

### Content Quality
- [ ] Is the meaning preserved accurately?
- [ ] Does it sound natural in English?
- [ ] Are technical terms correct and consistent?
- [ ] Is the complexity level appropriate for the audience?

### Voice & Tone
- [ ] Is it educational without being preachy?
- [ ] Is it welcoming to beginners?
- [ ] Is it intellectually honest (acknowledges tradeoffs)?
- [ ] Does it maintain libertarian perspective without aggression?
- [ ] Is it fact-based, not hype-based?

### Style
- [ ] Active voice where appropriate?
- [ ] Varied sentence length?
- [ ] Clear paragraph structure?
- [ ] Smooth transitions between ideas?

### Audience Appropriateness
- [ ] Terms defined on first use?
- [ ] Examples clear for English speakers?
- [ ] Cultural references adapted if needed?
- [ ] Complexity matches intended level?

---

## Real Examples from Bitcoin Starter

### Example 1: Technical Explanation (Beginner Level)

**Portuguese:**
"A cada 210.000 blocos minerados, o Bitcoin passa por um evento chamado 'halving', onde a recompensa dos mineradores é cortada pela metade. Isso acontece aproximadamente a cada quatro anos e reduz a taxa de criação de novos bitcoins, tornando-o cada vez mais escasso."

**Translation:**
"Every 210,000 blocks mined, Bitcoin undergoes an event called a 'halving', where the miner reward gets cut in half. This happens roughly every four years and reduces the rate of new bitcoin creation, making it increasingly scarce."

**Why this works:**
- ✅ Defines "halving" inline
- ✅ Active voice ("gets cut")
- ✅ Preserves technical accuracy
- ✅ Accessible explanation
- ✅ Natural English flow

---

### Example 2: Economic Concept (Intermediate Level)

**Portuguese:**
"O Efeito Cantillon descreve como a inflação beneficia desproporcionalmente aqueles que recebem o dinheiro novo primeiro - geralmente bancos e governo - enquanto prejudica os últimos a recebê-lo, geralmente trabalhadores com salário fixo."

**Translation:**
"The Cantillon Effect describes how inflation disproportionately benefits those who receive new money first - typically banks and governments - while harming those who receive it last, usually workers on fixed salaries."

**Why this works:**
- ✅ Explains concept clearly
- ✅ Maintains economic accuracy
- ✅ No added editorializing
- ✅ Concrete examples (banks, workers)
- ✅ Accessible to intermediate readers

---

### Example 3: Philosophical Argument (Advanced Level)

**Portuguese:**
"Bitcoin não é apenas uma inovação tecnológica, mas uma separação entre dinheiro e Estado. Assim como a separação entre Igreja e Estado protegeu a liberdade religiosa, a separação entre dinheiro e Estado protege a liberdade econômica individual."

**Translation:**
"Bitcoin isn't just a technological innovation - it enables separation of money and state. Just as the separation of church and state protected religious freedom, separating money from state power protects individual economic freedom."

**Why this works:**
- ✅ Preserves philosophical argument
- ✅ Maintains analogy structure
- ✅ Libertarian perspective without preaching
- ✅ Clear, powerful language
- ✅ Natural English phrasing

---

## When in Doubt

**Ask yourself:**
1. Would a native English-speaking Bitcoin educator write it this way?
2. Is it clear to someone encountering Bitcoin for the first time?
3. Does it maintain the original meaning without adding my own opinions?
4. Would I want to read this if I were learning about Bitcoin?

**If unsure:**
- Mark with [REVIEW: reason]
- Provide alternative translations
- Explain your reasoning

---

**Last Updated:** November 2024
**Version:** 1.0

*This guide ensures all Bitcoin Starter translations maintain consistent, high-quality voice that educates and empowers without preaching.*
