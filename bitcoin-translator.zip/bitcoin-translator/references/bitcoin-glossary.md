# Bitcoin Translation Glossary (PT→EN)

Comprehensive terminology guide for translating Bitcoin educational content from Portuguese to English.

## Core Bitcoin Terms

### NEVER TRANSLATE (Keep in English)

| Portuguese | English | Notes |
|-----------|---------|-------|
| halving | halving | NOT "redução pela metade" - established term |
| mining | mining | NOT "mineração" in final translation |
| blockchain | blockchain | NOT "cadeia de blocos" |
| hash | hash | Keep technical term |
| nonce | nonce | Keep technical term |
| proof-of-work | proof-of-work | NOT "prova de trabalho" |
| timestamp | timestamp | Keep as-is |
| fork | fork | Technical term (soft fork, hard fork) |
| mempool | mempool | Memory pool - keep term |
| UTXO | UTXO | Unspent Transaction Output |

### Bitcoin Capitalization Rules

| Term | Usage | Example |
|------|-------|---------|
| Bitcoin (capital B) | The network, protocol, or concept | "Bitcoin is a decentralized network" |
| bitcoin (lowercase b) | The currency unit | "I own 0.5 bitcoin" |
| BTC | Currency symbol | "1 BTC = 100,000,000 sats" |
| satoshi / sats | Smallest unit (1/100,000,000 BTC) | "Send me 1000 sats" |

## Technical Terms

| Portuguese | English | Context |
|-----------|---------|---------|
| carteira | wallet | Bitcoin wallet |
| chave privada | private key | Never "secret key" |
| chave pública | public key | |
| endereço | address | Bitcoin address |
| nó | node | Network node |
| bloco | block | Blockchain block |
| transação | transaction | |
| confirmação | confirmation | Block confirmation |
| taxa de transação | transaction fee | Or "fee" |
| recompensa de bloco | block reward | Miner reward |
| dificuldade | difficulty | Mining difficulty |
| hashrate | hashrate | Network hash rate |
| peer-to-peer | peer-to-peer | Or P2P |
| descentralizado | decentralized | |
| sem custódia | non-custodial | Wallet type |
| com custódia | custodial | Wallet type |
| auto-custódia | self-custody | Holding your own keys |
| semente / frase semente | seed phrase | 12/24 word recovery phrase |

## Lightning Network

| Portuguese | English | Notes |
|-----------|---------|-------|
| Rede Lightning | Lightning Network | Capital L, capital N |
| canal | channel | Lightning channel |
| roteamento | routing | Payment routing |
| invoice | invoice | Keep English term |
| zap | zap | Lightning tip (Nostr context) |
| nó Lightning | Lightning node | |
| liquidez | liquidity | Channel liquidity |
| fechar canal | close channel | |
| abrir canal | open channel | |

## Economic & Austrian Economics Terms

| Portuguese | English | Context/Notes |
|-----------|---------|---------------|
| inflação | inflation | Monetary inflation |
| deflação | deflation | |
| poder de compra | purchasing power | |
| escassez | scarcity | Digital scarcity |
| oferta | supply | Money supply |
| demanda | demand | |
| reserva de valor | store of value | SOV |
| meio de troca | medium of exchange | MOE |
| unidade de conta | unit of account | |
| dinheiro fiduciário | fiat money | Or "fiat currency" |
| dinheiro forte | hard money | Sound money |
| dinheiro fraco | soft money | Easy money |
| Efeito Cantillon | Cantillon Effect | Keep name |
| preferência temporal | time preference | Austrian economics |
| banco central | central bank | |
| expansão monetária | monetary expansion | Or "money printing" |
| flexibilização quantitativa | quantitative easing | QE |
| reserva fracionária | fractional reserve | Banking |
| padrão-ouro | gold standard | |
| moeda lastreada | backed currency | Gold-backed, etc. |
| curso forçado | legal tender | |

## Geopolitical & Historical Terms

| Portuguese | English | Context |
|-----------|---------|---------|
| Choque Nixon | Nixon Shock | 1971 event |
| Bretton Woods | Bretton Woods | System/Agreement |
| padrão dólar-ouro | dollar-gold standard | |
| petrodólar | petrodollar | |
| sanções econômicas | economic sanctions | |
| SWIFT | SWIFT | Keep acronym |
| soberania monetária | monetary sovereignty | |
| liberdade econômica | economic freedom | |
| separação entre dinheiro e Estado | separation of money and state | Key libertarian concept |
| confisco | confiscation | Asset seizure |
| controles de capital | capital controls | |
| hiperinflação | hyperinflation | |
| colapso monetário | monetary collapse | |

## Philosophical & Libertarian Terms

| Portuguese | English | Notes |
|-----------|---------|-------|
| soberania individual | individual sovereignty | Core concept |
| liberdade financeira | financial freedom | |
| privacidade financeira | financial privacy | |
| resistência à censura | censorship resistance | |
| neutro | neutral | Bitcoin is neutral money |
| sem permissão | permissionless | No need for approval |
| sem confiança | trustless | Don't need to trust parties |
| verificável | verifiable | "Don't trust, verify" |
| imutável | immutable | Cannot be changed |
| escasso | scarce | Digitally scarce |
| programável | programmable | |
| transparente | transparent | Blockchain transparency |
| pseudônimo | pseudonymous | Not anonymous |

## Common Phrases & Expressions

| Portuguese | English | Context |
|-----------|---------|---------|
| "Não são suas chaves, não são suas moedas" | "Not your keys, not your coins" | Famous Bitcoin saying |
| "Conserte o dinheiro, conserte o mundo" | "Fix the money, fix the world" | Common phrase |
| "Bitcoin não tem topo porque fiat não tem fundo" | "Bitcoin has no top because fiat has no bottom" | Popular expression |
| "Verifique, não confie" | "Don't trust, verify" | Core principle |
| "Seja seu próprio banco" | "Be your own bank" | Self-custody message |
| "Dinheiro justo" | "Fair money" | Bitcoin Starter tagline |
| "Empilhar sats" | "Stack sats" | Accumulating bitcoin |
| "HODL" | "HODL" | Hold On for Dear Life (keep meme) |
| "Para a lua" | "To the moon" | Price optimism (use sparingly) |

## Acronyms & Abbreviations

| Acronym | Portuguese | English | Notes |
|---------|-----------|---------|-------|
| BTC | Bitcoin | Bitcoin | Currency symbol |
| sat | satoshi | satoshi | Smallest unit |
| LN | Rede Lightning | Lightning Network | |
| UTXO | Saída de Transação Não Gasta | Unspent Transaction Output | |
| P2P | ponto-a-ponto | peer-to-peer | |
| PoW | Prova de Trabalho | Proof-of-Work | |
| KYC | Conheça Seu Cliente | Know Your Customer | |
| AML | Anti-Lavagem de Dinheiro | Anti-Money Laundering | |
| CBDC | Moeda Digital de Banco Central | Central Bank Digital Currency | |
| DCA | Média de Custo em Dólar | Dollar Cost Averaging | |
| ATH | Máxima Histórica | All-Time High | |
| FUD | Medo, Incerteza e Dúvida | Fear, Uncertainty, Doubt | |
| FOMO | Medo de Ficar de Fora | Fear Of Missing Out | |

## Wallet Types

| Portuguese | English | Context |
|-----------|---------|---------|
| carteira quente | hot wallet | Online, connected |
| carteira fria | cold wallet | Offline storage |
| carteira de hardware | hardware wallet | Physical device |
| carteira de papel | paper wallet | Printed keys |
| carteira móvel | mobile wallet | Phone app |
| carteira desktop | desktop wallet | Computer software |
| carteira web | web wallet | Browser-based |
| multisig | multisig | Multi-signature wallet |

## Security & Best Practices

| Portuguese | English | Context |
|-----------|---------|---------|
| backup | backup | Seed phrase backup |
| recuperação | recovery | Wallet recovery |
| frase de recuperação | recovery phrase | = seed phrase |
| senha adicional | passphrase | Optional extra word |
| autenticação de dois fatores | two-factor authentication | 2FA |
| phishing | phishing | Scam attempt |
| golpe | scam | Fraud |
| ataque de 51% | 51% attack | Network attack |
| gasto duplo | double spend | Double-spending attack |

## Exchange & Trading Terms

| Portuguese | English | Context |
|-----------|---------|---------|
| corretora | exchange | Crypto exchange |
| P2P | P2P | Peer-to-peer trading |
| ordem de compra | buy order | |
| ordem de venda | sell order | |
| livro de ordens | order book | |
| liquidez | liquidity | Market liquidity |
| par de negociação | trading pair | BTC/USD, etc. |
| arbitragem | arbitrage | Price differences |

## Common Translation Mistakes to AVOID

| ❌ Wrong | ✅ Correct | Why |
|---------|----------|-----|
| "redução pela metade" | "halving" | Established English term |
| "mineração" (in final text) | "mining" | Keep English technical terms |
| "blockchain de Bitcoin" | "Bitcoin blockchain" | English word order |
| "moeda virtual" | "digital currency" | More accurate |
| "dinheiro eletrônico" | "electronic cash" | Or "digital cash" |
| "Bitcoin é revolucionário" | "Bitcoin enables..." | Avoid hype adjectives |
| "investir em Bitcoin" | "buy Bitcoin" or "save in Bitcoin" | "Invest" implies speculation |
| "criptomoeda" | "cryptocurrency" (or just "Bitcoin") | Be specific |

## Tone & Style Guidelines

### Do:
- Use active voice: "Bitcoin enables" not "is enabled by"
- Be concise: Prefer shorter, clearer sentences
- Be specific: "21 million bitcoin" not "limited supply"
- Define acronyms on first use: "Dollar Cost Averaging (DCA)"
- Use consistent terminology throughout a document

### Don't:
- Don't translate established technical terms
- Don't add hype not in original: "revolutionary", "game-changer"
- Don't assume knowledge: Explain concepts clearly
- Don't use jargon without context
- Don't be overly literal: Adapt for natural English flow

## Special Cases

### When to Keep Portuguese

Only keep Portuguese terms when:
1. Referring to Brazil-specific context: "Brazilian Real (BRL)"
2. Quoting someone in Portuguese (then translate in brackets)
3. Discussing Portuguese-language resources

### When to Add Context

Add brief explanatory context when:
- Historical reference may be unfamiliar: "The Nixon Shock (when the US abandoned the gold standard in 1971)..."
- Brazilian-specific example needs adaptation
- Technical term appears for first time in document
- Geopolitical reference needs clarification for international audience

---

**Last Updated:** November 2024
**Version:** 1.0

*This glossary is optimized for Bitcoin Starter project translations and follows industry-standard Bitcoin terminology.*
