---
name: bitcoin-translator
description: Specialized PT→EN translator for Bitcoin educational content, maintaining technical accuracy, libertarian tone, and Austrian economics perspective. Use when translating Bitcoin-related content from Portuguese to English for the Bitcoin Starter educational platform.
---

# Bitcoin Translator

Specialized translation skill for converting Bitcoin educational content from Portuguese to English while preserving technical accuracy, libertarian philosophy, and educational tone.

## Purpose

This skill enables high-quality translation of Bitcoin educational materials from Portuguese to English, specifically designed for the Bitcoin Starter platform. It maintains:

- **Technical accuracy** - Correct Bitcoin terminology and concepts
- **Libertarian tone** - Austrian economics perspective, individual sovereignty focus
- **Educational clarity** - Beginner-friendly explanations without being preachy
- **Cultural context** - Adapts geopolitical references for English-speaking audiences
- **Consistency** - Standardized terminology across all content

## When to Use This Skill

Use this skill when:

- Translating course lessons from Portuguese source materials
- Converting blog posts about Bitcoin economics or technology
- Translating educational content for the Learn Path (Levels 1-8)
- Adapting Bitcoin-related quotes or excerpts
- Creating English versions of Bitcoin policy discussions

Do NOT use for:
- Non-Bitcoin content
- Literal/legal documents (requires legal translator)
- Marketing copy (different tone required)

## Translation Workflow

### Step 1: Analyze Source Content

Before translating:

1. **Read** the full Portuguese text to understand context
2. **Identify** key concepts:
   - Technical terms (mining, halving, nodes, etc.)
   - Economic concepts (inflation, Cantillon Effect, etc.)
   - Geopolitical references (Nixon Shock, Bretton Woods, etc.)
3. **Note** the intended audience level (beginner, intermediate, advanced)
4. **Check** the tone (educational, analytical, philosophical)

### Step 2: Apply Translation Strategy

**For Technical Terms:**
- Consult `references/bitcoin-glossary.md` for standardized translations
- NEVER translate established Bitcoin terms (e.g., "halving" stays "halving", not "redução pela metade")
- Preserve capitalization conventions (Bitcoin vs bitcoin, Lightning Network vs lightning network)

**For Economic Concepts:**
- Use Austrian economics terminology when applicable
- Explain concepts clearly without assuming prior knowledge
- Add brief context if the English-speaking audience may be unfamiliar

**For Cultural/Geopolitical References:**
- Adapt Brazilian-specific examples to international equivalents when needed
- Keep historical references (Nixon Shock, Bretton Woods) but ensure clarity
- Add brief explanatory context if a reference may be obscure to English speakers

**For Tone:**
- Refer to `references/tone-guide.md` for voice guidelines
- Maintain welcoming but intellectually honest approach
- Avoid hype language ("revolutionary", "game-changer") unless in original context
- Preserve libertarian philosophy without being preachy

### Step 3: Translate Section by Section

**Structure:**
1. Translate paragraph by paragraph, not sentence by sentence
2. Preserve markdown formatting (headers, lists, bold, italics, links)
3. Maintain paragraph breaks and visual structure
4. Keep code blocks, quotes, and special formatting intact

**Quality checks:**
- Read translation aloud - does it sound natural in English?
- Check: Did technical terms stay consistent?
- Verify: Is the tone appropriate (educational, not marketing)?
- Confirm: Are examples clear for English speakers?

### Step 4: Review & Polish

After completing translation:

1. **Read full translation** as if encountering it fresh
2. **Check consistency** - same terms translated the same way throughout?
3. **Verify flow** - does it read naturally in English?
4. **Mark uncertainties** - flag any sections needing human review with `[REVIEW: reason]`
5. **Add translator notes** if needed: `[TRANSLATOR NOTE: context or reasoning]`

### Step 5: Output Format

Present translation as:

```markdown
# [Original Title in English]

[Translated content maintaining all original formatting]

---

## Translation Notes (if any)

- [Any context, uncertainties, or recommendations]
```

## Bundled Resources

### references/bitcoin-glossary.md

Comprehensive PT→EN glossary of Bitcoin terminology with usage notes. Consult this for:
- Standard Bitcoin technical terms
- Economic concepts (Austrian economics focus)
- Geopolitical/historical terms
- Acronyms and abbreviations

### references/tone-guide.md

Voice and tone guidelines for the Bitcoin Starter brand. Consult this for:
- Writing style principles
- Dos and don'ts
- Example passages showing correct tone
- Common pitfalls to avoid

## Common Translation Patterns

### Pattern 1: Technical Explanations

**Portuguese structure:** Often uses more words, passive voice
**English preference:** Concise, active voice

Example:
- PT: "O processo de mineração é realizado por computadores que resolvem problemas matemáticos complexos"
- EN: "Mining happens when computers solve complex mathematical problems"

### Pattern 2: Libertarian Philosophy

**Preserve core message** but adapt cultural context:

Example:
- PT: "Bitcoin representa a separação entre dinheiro e Estado, assim como houve separação entre Igreja e Estado"
- EN: "Bitcoin enables separation of money and state, similar to how church and state were separated"

### Pattern 3: Beginner-Friendly Tone

**Balance:** Technical accuracy + accessibility

Example:
- PT: "A cada 210.000 blocos minerados, a recompensa dos mineradores é reduzida pela metade"
- EN: "Every 210,000 blocks mined, the miner reward gets cut in half - this is called a 'halving'"

## Quality Standards

A good translation should:

- ✅ Use correct Bitcoin terminology (check glossary)
- ✅ Sound natural to native English speakers
- ✅ Maintain libertarian/Austrian economics perspective
- ✅ Be accessible to beginners (when source is beginner-focused)
- ✅ Preserve technical accuracy
- ✅ Flow well when read aloud

A translation needs revision if:

- ❌ Contains literal word-for-word translations that sound awkward
- ❌ Uses incorrect or inconsistent Bitcoin terms
- ❌ Loses the libertarian philosophical tone
- ❌ Adds marketing hype not present in original
- ❌ Makes assumptions about knowledge level
- ❌ Breaks markdown formatting

## Tips for Excellence

1. **Don't be too literal** - prioritize meaning over word-for-word translation
2. **Respect the source** - don't add opinions or change the message
3. **Keep it natural** - English should read like it was written in English
4. **Flag uncertainties** - mark sections needing human review
5. **Stay consistent** - use same translations for recurring terms
6. **Context matters** - adapt for English-speaking cultural context when needed

## Example Usage

**User request:**
"Traduza este trecho do PDF sobre a história do dinheiro"

**Process:**
1. Read the Portuguese text about money history
2. Consult glossary for economic terms
3. Check tone guide for educational style
4. Translate maintaining libertarian perspective
5. Ensure clarity for English speakers unfamiliar with Brazilian economic history
6. Format properly with markdown
7. Add [REVIEW] flags if any sections are uncertain
8. Output polished English translation

---

*This skill is optimized for the Bitcoin Starter project's educational content, maintaining high standards of technical accuracy and philosophical consistency.*
